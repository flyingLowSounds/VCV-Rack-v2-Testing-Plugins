
True Type Font: LED Counter-7 version 1.0


EULA
-==-
The font LED Counter-7 is freeware for home using only.


DESCRIPTION
-=========-
This is original italic font created in style a LED (Light Emitting Diode) matrix 5*7 units.

Files in led_counter-7.zip:
       	readme.txt     				this file;
        led_counter-7.ttf    			regular true type font;
        led_counter-7_italic.ttf    		italic true type font;
	led_counter-7_screen.gif		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments: please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95) or use this link: 
http://store.esellerate.net/s.aspx?s=STR0331655240

You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


WHAT'S NEW?
-=========-
Version 1.1 (August 16 2013)
 * Regular style is added;
 * Fixed bugs: void nodes are deleted.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: June 26 2013