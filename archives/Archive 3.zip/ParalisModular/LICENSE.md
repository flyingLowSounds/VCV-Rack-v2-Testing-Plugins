All **source code** in `src/` is copyright © 2019 Andrew Belt and Audible Instruments contributers and is licensed under the [GNU General Public License v3.0](LICENSE-GPLv3.txt).

The **panel graphics** in the `res/` directory are copyright © Emilie Gillet and are used and distributed with permission.

**Dependencies** included in the binary distributable may have other licenses.
See [LICENSE-dist.txt](LICENSE-dist.txt) for a full list.