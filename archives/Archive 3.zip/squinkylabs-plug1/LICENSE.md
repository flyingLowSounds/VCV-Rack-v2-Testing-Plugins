# SquinkyLabs - License

All **source code** is copyright © 2018-2021 SquinkyLabs and is licensed under [GNU General Public License v3.0](LICENSE), 
with the exception of certain code excerpts (see [LICENSE-dist](LICENSE-dist.txt)).

The **panel graphics** in the `res` directory are copyright © 2018-201921 SquinkyLabs and licensed under [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/),
 with the exception of certain component graphics which are adaptations from the VCV Rack Component library, which is copyright © 2019 Grayscale and licensed under [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/).

 As mentioned in the readme: 
 ```Note that "Squinky Labs" is not a registered trademark, nor is the ugly logo that says "Squinky Labs" in a font called "Space Patrol". None the less, the name and logo have been used as our brand. While it is probably legal and permitted to re-use these, we would kindly ask that you not use them and develop your own name/trademark.```
 