# Fonts used by Chortling Hamster Modules

The following fonts are used on modules' front panels.

## Sniglet by Haley Fiege

Sniglet is used for the module name.

More information at <https://www.theleagueofmoveabletype.com/sniglet>.

## Francois One by Vernon Adams

Francois One is used for the port and parameter labels.

More information at <https://github.com/vernnobile/Francois>.

## DSEG

DSEG is used for the "calculator style" number displays.

More information at <https://github.com/keshikan/DSEG>.
