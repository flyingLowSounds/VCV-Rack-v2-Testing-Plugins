All **source code** is copyright © 2021 Alan Holding and is licensed under the [GNU General Public License v3.0](LICENSE-GPLv3.txt).

All **graphics** in the `res` directory, excluding the `res/fonts` directory, are copyright © 2021 Alan Holding and licensed under [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).
