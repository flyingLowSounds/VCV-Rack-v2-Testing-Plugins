All **source code**, excluding the contents of lib/, is copyright © 2020 Matt Demanett and is licensed under the [GNU General Public License v3.0 or later (GPL-3.0-or-later)](gpl-3.0.txt).  For lib/, see [LICENSE-dist.md](LICENSE-dist.md).

All **graphics** in the `res` and `res-src` directories are copyright 2020 Matt Demanett and licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).
