# Impromptu Modular - License

All **source code** is copyright © 2018-2021 Marc Boulé and is licensed under [GNU General Public License v3.0](LICENSE), with the exception of certain Fundamental and code excepts (see [LICENSE-ext](LICENSE-ext.md)).

The **Impromptu Modular name and logo** are copyright © 2018-2021 Marc Boulé and may not be used in derivative works.

The **panel graphics** in the `res` directory are copyright © 2018-2021 Marc Boulé and licensed under [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/), with the exception of certain component graphics which are adaptations from the VCV Rack Component library, which is copyright © 2019 VCV and licensed under [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).

