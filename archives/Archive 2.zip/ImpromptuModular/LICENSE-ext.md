#### FUNDAMENTAL ####

All source code is copyright © 2016-2021 Andrew Belt and is licensed under the GNU General Public License v3.0 (see [LICENSE](LICENSE)).


#### AUDIBLE INSTRUMENTS ####

All source code in the src/ folder is copyright © 2016-2020 Andrew Belt and Audible Instruments contributers and is licensed under the GNU General Public License v3.0 (see [LICENSE](LICENSE)).


#### BLANK PANEL ####

The lightning svg used to make the Blank panel has the following license :

http://www.supercoloring.com/silhouettes/lightning

Author: Natasha Sinegina 

This silhouette is a derivative work (tracing copy). Original image credit: Lightning in Zdolbuniv photo by Lyoha123 

Permission:  Some rights reserved. This work is licensed under a Creative Commons Attribution-Share Alike 4.0 License. 

You are free to share or adapt it for any purpose, even commercially under the following terms: you must give a link to this page and indicate the author's name and the license.