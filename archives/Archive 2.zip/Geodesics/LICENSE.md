# Geodesics - License

All **source code** is copyright © 2018-2019 Marc Boulé and is licensed under [GNU General Public License v3.0](LICENSE), with the exception of certain Fundamental, Audible Instruments and Bog Audio code excepts (see [LICENSE-ext](LICENSE-ext.md))

The **Geodesics name and logo** are copyright © 2018-2019 Pierre Collard (Pyer) and may not be used in derivative works.

The **panel graphics** in the `res` directory are copyright © 2018-2019 Pierre Collard (Pyer) and licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).

