# Mind Meld Modular - License

All **source code** is copyright © 2019 Marc Boulé and Steve Baker, and licensed under GPL-v3 (see [LICENSE](LICENSE) in the root of this github repository).

The **Mind Meld Modular logo and icon** are copyright © 2021 Steve Baker and may not be used in derivative works.

The **visual design** of the modules, and the **panel graphics** in the `res` directory are copyright © 2021 Steve Baker and licensed under [CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).
